

let checkLogin = (email,password,allusers)=>{
   
    let isUserFound = false;
    let passwordCorrect = false;

    for( const currentUser of allUsers){
        console.log(currentUser);
        
        if(allUser[currentUser]['email'] == email){

            if (allUser[currentUser]['password'] == password){
                isUserFound = true
                passwordCorrect = true
                break;
            } else{
                isUserFound = true
                passwordCorrect = false
                break;
            }
        } else{
            isUserFound = false
        }
        
    }
}