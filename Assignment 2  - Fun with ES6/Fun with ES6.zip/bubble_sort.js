let a = [10, 8, 9];
let bubble_Sort = (a) => {
    let swapp;
    let i;
    do {
        swapp = false;
        for (i = 0; i < a.length - 1; i++) {
            if (a[i] < a[i + 1]) {

                let temp = a[i];
                a[i] = a[i + 1];
                a[i + 1] = temp;
                swapp = true;
            }
        }
    } while (swapp);

}


bubble_Sort(a);
console.log(a);